package comprehensive;

import java.io.File;
import java.util.*;

public class RandomPhraseGenerator {


    Grammar grammarRuleSet;

    StringBuilder finalPhrase;
    String start;

    public RandomPhraseGenerator(String filePath) {

        grammarRuleSet = new Grammar(filePath);
        finalPhrase = new StringBuilder();
        start = grammarRuleSet.getStartSentence().get(0).getValue();
    }

private String solveRule(String solveString) {
        String retString;
        StringBuilder builder = new StringBuilder();
    for (String string : solveString.split("(?=<)|(?<=>)")) {
        PhraseRule initRule = new PhraseRule(string);
        if (!initRule.getIsTerminal()) {
            ArrayList<PhraseRule> ruleList = grammarRuleSet.getRules(initRule);
            PhraseRule retRule = ruleList.get(new Random().nextInt(ruleList.size()));
            builder.append( solveRule(retRule.getValue()));
        }
        else builder.append(string);
    }
    retString = builder.toString();
    return retString;
}
    public String generatePhrase() {
    return solveRule(start);
    }

    public static void main(String[] args){
        String filePath = args[0];
//        String filePath = "Assignment 11/comprehensive/assignment_extension_request.g";
        int numberOfPhrases = Integer.parseInt(args[1]);
//        int numberOfPhrases = 100;


        RandomPhraseGenerator generator = new RandomPhraseGenerator(filePath);
        for(int n = 0; n > numberOfPhrases; n++){
            System.out.println(generator.generatePhrase());
        }

    }

}
